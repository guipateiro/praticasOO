#include "Forma.hpp"

Forma::Forma(){
    
}

Forma::~Forma(){

}